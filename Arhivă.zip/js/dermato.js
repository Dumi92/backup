
$(document).ready(function(){
	// RNAV dr feature

	//Popescu
	$('a#popescu').mouseenter(function() {
		$('#stuffImage').addClass('popescu');
	});
	$('a#popescu').mouseleave(function() {
		$('#stuffImage').removeClass('popescu');
	});

	//Ionescu
	$('a#ionescu').mouseenter(function() {
		$('#stuffImage').addClass('ionescu');
	});
	$('a#ionescu').mouseleave(function() {
		$('#stuffImage').removeClass('ionescu');
	});

});