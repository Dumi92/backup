function initMap() {
    var uluru = { lat: 44.314674, lng: 23.795645 };
    var map = new google.maps.Map(document.getElementById('map'), {
        zoom: 16,
        center: uluru
    });
    var marker = new google.maps.Marker({
        position: uluru,
        map: map
    });
}
/*$( document ).ready(function() {
    var recaptchachecked;
    function recaptchaCallback() {
        recaptchachecked = true
        $('#btn').removeAttr('disabled');
    }
});*/


function recaptchaCallback(){ 
     var response = grecaptcha.getResponse();
     if(response != '0'){
           //captcha validated and got response code
            $('#btn').removeAttr('disabled').css('background-color','#71475e');
        
     }else{
           //not validated or not clicked
           $('#btn').attr('disabled');
     }
     
}
/*$(document).ready(function(){
   $("#btn").click(function(){
      $("#map").remove();
      $(".g-recaptcha").remove();
   }); 
});*/



$(function() {
    
    if(Modernizr.history){

    var i = 0;
    var newHash      = "",
        $mainContent = $("#main-content"),
        $pageWrap    = $("#page-wrap"),
        
        $el;
        
    //  $pageWrap.height($pageWrap.height());
    
    
    
    $("nav").delegate("a", "click", function() {
        _link = $(this).attr("href");
        history.pushState(null, null, _link);
        loadContent(_link);
        return false;
    });

    function loadContent(href){
 
        var arr = ["fb.jpg",  "mihai.jpg", "patrat.jpg", "mihai2.jpg"];
        var item = arr[Math.floor(Math.random() * (arr.length -1))];


         $('.md2').attr('src', item);

        $pageWrap
                .find(".md2").attr('src', item);
        $mainContent
                .find("#guts")
                .fadeOut(200, function() {
                    $mainContent.hide().load(href + " #guts", function() {
                        $mainContent.fadeIn(200, function() {

                        });
                    });
                });
    }
    
    $(window).bind('popstate', function(){
      _link = location.pathname.replace(/^.*[\\\/]/, ''); //get filename only
      loadContent(_link);
    });




} // otherwise, history is not supported, so nothing fancy here.
    window.onbeforeunload = function() {
        alert ( "Dude, are you sure you want to refresh? Think of the kittens!") ;
}
    
});
