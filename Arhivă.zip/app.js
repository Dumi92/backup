require(["jquery", "js/jquery.validate"], function ($) {
    $.validator.setDefaults({
        submitHandler: function () {
        }
    });
    // validate the comment form when it is submitted
    $("#commentForm").validate();
});